# import main Flask class and request object
from flask import Flask, request,render_template
from bs4 import BeautifulSoup
from urllib.request import urlopen 
from flask_mysqldb import MySQL

# create the Flask app

app=Flask(__name__)


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'ecom'

mysql = MySQL(app)


html = urlopen('file:///C:/Users/lenovo/Desktop/pfw/templates/index.html')

@app.route("/")
def index():
    return render_template('index.html');

@app.route('/move_forward')
def move_forward():
   
        ip=request.remote_addr
        soup = BeautifulSoup(html,'html.parser')
        soup2=soup.find('h1')
        product=soup2.text
        print("Product Details :",product)
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO click_events(ip_address, product_details) VALUES (%s, %s)", (ip, product))
        mysql.connection.commit()
        cur.close()
        
        return render_template('cart.html')
    
if __name__ == '__main__':
    # run app in debug mode on port 5000
    app.run(debug=True,port=5000)